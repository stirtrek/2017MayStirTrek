USE [AdventureWorks2014]
GO

--Setup
--Create the bobblehead product, if you haven't already
INSERT INTO [AdventureWorks2014].[Production].[Product]
(
	Name,
	ProductNumber,
	MakeFlag,
	FinishedGoodsFlag,
	SafetyStockLevel,
	ReorderPoint,
	StandardCost,
	ListPrice,
	Weight,
	DaysToManufacture,
	SellStartDate
)
VALUES
(
	'Commerative Bobblehead',
	'OO-PS-00-00',
	1,
	1,
	1000,
	10,
	29.99,
	0.00,
	1.5,
	3,
	GETDATE()
)

INSERT INTO Sales.SpecialOfferProduct (SpecialOfferID, ProductID) VALUES (1, 1000)

--Drop the procs you created
DROP PROCEDURE dbo.GetAddressesForSpecificState
GO
--Make sure the temp table is there in AW
CREATE SCHEMA Temp
GO
SELECT * INTO Temp.ProductArchive
FROM Production.Product

--Is the demo index there on SO.Posts?
USE [StackOverflow]
GO

CREATE NONCLUSTERED INDEX [IX_Posts_OwnerUserID_5] ON [dbo].[Posts]
(
	[OwnerUserId] ASC
)
INCLUDE ( 	[Id],
	[AcceptedAnswerId],
	[AnswerCount],
	[ViewCount]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

--Free the proc cache
DBCC FREEPROCCACHE
--Set time and statistics off
SET STATISTICS TIME, IO OFF
--Drop the buffers
DBCC DROPCLEANBUFFERS
--Check MAXDOP and CTFP
EXECUTE sp_configure 'max degree of parallelism',0
EXECUTE sp_configure 'cost threshold for parallelism',5
RECONFIGURE


--Is the plan store on?
ALTER DATABASE [StackOverflow] SET QUERY_STORE = ON;


USE [AdventureWorks2014]
GO


-- Demo 10.1
-- Plan examples				
-- A simple select from a table
-- Clustered Index Scans
SELECT * FROM Production.Product
SELECT * FROM Temp.ProductArchive



-- Another simple select... or is it?
SELECT * FROM Sales.Customer



-- Let's add a predicate!
SELECT * FROM Person.Person
WHERE PersonType = 'EM'

SELECT * FROM Person.Person
WHERE BusinessEntityID = 1

-- Wait... why was that still a clustered scan?	We used a predicate and everything!
-- Shouldn't it use an index?
SELECT FirstName, LastName FROM Person.Person
WHERE LastName = 'Smith'
--How do we quantify the differences in operators?
SET STATISTICS IO ON

SELECT * FROM Person.Person
WHERE PersonType = 'EM'

SELECT * FROM Person.Person
WHERE LastName = 'Smith'

SELECT FirstName, LastName FROM Person.Person
WHERE LastName = 'Smith'

SELECT FirstName, LastName FROM Person.Person
WHERE FirstName = 'Andrew'

SET STATISTICS IO OFF



--Hey look, a SORT operator!
--SELECT * FROM Production.Product
--ORDER BY ProductNumber ASC

SELECT * FROM Person.Person
ORDER BY PersonType ASC

-- But sorts can benefit from indexes, too
SELECT FirstName, LastName FROM	Person.Person
ORDER BY FirstName

SELECT FirstName, LastName FROM	Person.Person
ORDER BY LastName

-- Especially if the index is already sorted in the way you want it
--SELECT FirstName, LastName FROM Person.Person
--WHERE LastName = 'Smith'
--ORDER BY FirstName ASC



--Demo 11.1
--JOINS (Hash match vs. Nested Loops vs. Merge Joins)
--Let's look at some complex plans
--Remember: Right to Left, top to bottom
--What's a merge join?
SELECT P.LastName, P.FirstName, E.EmailAddress 
FROM Person.Person P
INNER JOIN Person.EmailAddress E ON E.BusinessEntityID = P.BusinessEntityID
WHERE LastName = 'Smith'

--Demo 11.2
--Hash match joins
SELECT SOH.OrderDate, SOH.ShipDate, SOH.SubTotal, SD.SalesOrderID, SOH.OrderDate, SD.SalesOrderDetailID, SD.CarrierTrackingNumber, SD.ProductID, P.Name, P.ProductNumber
FROM Sales.SalesOrderDetail SD
INNER JOIN Sales.SalesOrderHeader SOH ON SOH.SalesOrderID = SD.SalesOrderID
INNER JOIN Production.Product P ON P.ProductID = SD.ProductID
WHERE SOH.OrderDate BETWEEN '1/1/2013' AND '12/31/2016'

--Demo 11.3
--Nested Loops Join
SELECT E.BusinessEntityID, E.LoginID, E.JobTitle, P.FirstName, P.LastName
FROM HumanResources.Employee E
INNER JOIN Person.Person P ON P.BusinessEntityID = E.BusinessEntityID


--Demo 13.1
--Parameter Sniffing
--Let's fire off three queries
USE [AdventureWorks2014]
GO

SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
FROM Person.Address
WHERE StateProvinceID = 55

SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
FROM Person.Address
WHERE StateProvinceID = 59

SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
FROM Person.Address
WHERE StateProvinceID = 9
GO

--DROP PROCEDURE GetAddressesForSpecificState
--What if we make a stored procedure?
CREATE PROCEDURE GetAddressesForSpecificState
(
	@StateProvinceID int
)
AS
BEGIN
	SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
	FROM Person.Address
	WHERE StateProvinceID = @StateProvinceID
END

EXECUTE GetAddressesForSpecificState 9
GO
EXECUTE GetAddressesForSpecificState 55
GO
--How can we fix it?
--Recompile?
ALTER PROCEDURE GetAddressesForSpecificState
(
	@StateProvinceID int
)
WITH RECOMPILE
AS
BEGIN
	SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
	FROM Person.Address
	WHERE StateProvinceID = @StateProvinceID
END

EXECUTE GetAddressesForSpecificState 9
GO
EXECUTE GetAddressesForSpecificState 55
GO

--Optimize for specific value/unknown?
ALTER PROCEDURE GetAddressesForSpecificState
(
	@StateProvinceID int
)
AS
BEGIN
	SELECT AddressLine1, AddressLine2, City, StateProvinceID, PostalCode
	FROM Person.Address
	WHERE StateProvinceID = @StateProvinceID
	OPTION (OPTIMIZE FOR (@StateProvinceID=55));
END

EXECUTE GetAddressesForSpecificState 9
GO
EXECUTE GetAddressesForSpecificState 55
GO


--Demo 14.1
--Table Variables vs. Temp Tables
--1 != 1

DECLARE @Customers AS TABLE
(
	BusinessEntityID int,
	CustomerFirst nvarchar(255),
	CustomerLast nvarchar(255)
)

INSERT INTO @Customers (BusinessEntityID, CustomerFirst, CustomerLast)
SELECT TOP 1 P.BusinessEntityID, P.FirstName, P.LastName
  FROM Person.Person P
  INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID 
  INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
  INNER JOIN Person.StateProvince SP ON A.StateProvinceID = SP.StateProvinceID
  WHERE SP.Name = 'Washington'


SELECT * FROM Sales.SalesOrderHeader SOH
INNER JOIN Sales.SalesOrderDetail SOD ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN @Customers C ON C.BusinessEntityID = SOH.CustomerID
GO

--Now, let's scale up

SET STATISTICS IO ON

DECLARE @Customers AS TABLE
(
	BusinessEntityID int,
	CustomerFirst nvarchar(255),
	CustomerLast nvarchar(255)
)

INSERT INTO @Customers (BusinessEntityID, CustomerFirst, CustomerLast)
SELECT TOP 5000 P.BusinessEntityID, P.FirstName, P.LastName
  FROM Person.Person P
  INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID 
  INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
  INNER JOIN Person.StateProvince SP ON A.StateProvinceID = SP.StateProvinceID


SELECT * FROM Sales.SalesOrderHeader SOH
INNER JOIN Sales.SalesOrderDetail SOD ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN @Customers C ON C.BusinessEntityID = SOH.CustomerID



CREATE TABLE #Customers
(
	BusinessEntityID int,
	CustomerFirst nvarchar(255),
	CustomerLast nvarchar(255)
)
INSERT INTO #Customers (BusinessEntityID, CustomerFirst, CustomerLast)
SELECT TOP 5000 P.BusinessEntityID, P.FirstName, P.LastName
  FROM Person.Person P
  INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID 
  INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
  INNER JOIN Person.StateProvince SP ON A.StateProvinceID = SP.StateProvinceID

SELECT * FROM Sales.SalesOrderHeader SOH
INNER JOIN Sales.SalesOrderDetail SOD ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN #Customers C ON C.BusinessEntityID = SOH.CustomerID


--Demo 15.1
--Cursors... yuck!
--Show how the plan is generated FOR EACH ROW!
USE [AdventureWorks2014]
GO

--We screwed up, so let's make it up to our customers... all of them!
BEGIN TRANSACTION

DECLARE @CustomerID int
DECLARE @AddressID int
DECLARE @SalesOrderHeaderID int

DECLARE Customer CURSOR FOR
SELECT CustomerID, A.AddressID FROM Sales.Customer C
INNER JOIN Person.Person P ON P.BusinessEntityID = C.CustomerID
INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID
INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID

OPEN Customer

FETCH NEXT FROM Customer 
INTO @CustomerID, @AddressID

WHILE @@FETCH_STATUS = 0
BEGIN

	INSERT INTO Sales.SalesOrderHeader (
		RevisionNumber, 
		OrderDate, 
		DueDate, 
		[Status], 
		OnlineOrderFlag, 
		CustomerID, 
		BillToAddressID, 
		ShipToAddressID,
		ShipMethodID, 
		SubTotal, 
		TaxAmt, 
		Freight
		)
	VALUES (
		0,
		GETDATE(),
		DATEADD(dd,7,GETDATE()),
		1,
		0,
		@CustomerID,
		@AddressID,
		@AddressID,
		1,
		0.00,
		0.00,
		0.00
	)

	SET @SalesOrderHeaderID = SCOPE_IDENTITY()

	INSERT INTO Sales.SalesOrderDetail (SalesOrderID, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount)
	VALUES (@SalesOrderHeaderID, 1, 1000, 1, 0.00, 0.00) 

	FETCH NEXT FROM Customer 
	INTO @CustomerID, @AddressID
END

CLOSE Customer;
DEALLOCATE Customer;

ROLLBACK

--That was pretty terrible!
--One plan for every insert... and it was taking soooooooooo long!
--Now let's fix the cursor with something fun

BEGIN TRANSACTION

CREATE TABLE #NewSales
(
	SalesOrderID INT PRIMARY KEY
)

INSERT INTO Sales.SalesOrderHeader 
(
	RevisionNumber, 
	OrderDate, 
	DueDate, 
	[Status], 
	OnlineOrderFlag, 
	CustomerID, 
	BillToAddressID, 
	ShipToAddressID,
	ShipMethodID, 
	SubTotal, 
	TaxAmt, 
	Freight
)
OUTPUT INSERTED.SalesOrderID INTO #NewSales
SELECT 0, GETDATE(), DATEADD(dd,7,GETDATE()), 1, 0, CustomerID, A.AddressID, A.AddressID, 1, 0.00, 0.00, 0.00 
FROM Sales.Customer C
INNER JOIN Person.Person P ON P.BusinessEntityID = C.CustomerID
INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID
INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID

SELECT * FROM #NewSales

INSERT INTO Sales.SalesOrderDetail (SalesOrderID, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount)
SELECT SalesOrderID, 1, 1000, 1, 0.00, 0.00 FROM #NewSales

DROP TABLE #NewSales

ROLLBACK


--Demo 20.1
--Don't go chasing indexes
SELECT P.PersonType, P.Title, P.FirstName, P.Lastname, A.AddressLine1, A.AddressLine1, A.City, SP.Name AS State, A.PostalCode, AT.Name AS AddressType
FROM Person.Person P
INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID
INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
INNER JOIN Person.AddressType AT ON AT.AddressTypeID = BEA.AddressTypeID
INNER JOIN Person.StateProvince SP ON SP.StateProvinceID = A.StateProvinceID 
WHERE SP.Name = 'California' AND FirstName = 'Alexandra'


--What does the update look like in the estimated plan?
BEGIN TRANSACTION
UPDATE P
SET P.FirstName = 'Alex'
FROM Person.Person P
INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID
INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
INNER JOIN Person.AddressType AT ON AT.AddressTypeID = BEA.AddressTypeID
INNER JOIN Person.StateProvince SP ON SP.StateProvinceID = A.StateProvinceID 
WHERE SP.Name = 'California' AND FirstName = 'Alexandra'
ROLLBACK

CREATE NONCLUSTERED INDEX [IX_Person_FirstName]
ON [Person].[Person] ([FirstName])

--Now what does the update look like in the estimated plan and actual?
BEGIN TRANSACTION
UPDATE P
SET P.FirstName = 'Alex'
FROM Person.Person P
INNER JOIN Person.BusinessEntityAddress BEA ON BEA.BusinessEntityID = P.BusinessEntityID
INNER JOIN Person.Address A ON A.AddressID = BEA.AddressID
INNER JOIN Person.AddressType AT ON AT.AddressTypeID = BEA.AddressTypeID
INNER JOIN Person.StateProvince SP ON SP.StateProvinceID = A.StateProvinceID 
WHERE SP.Name = 'California' AND FirstName = 'Alexandra'
ROLLBACK

DROP INDEX [IX_Person_FirstName] ON [Person].[Person]

--Demo 21.1
--Live query execution of a complex query
USE [StackOverflow]
GO

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
GO

SELECT P.Id, P.CreationDate, P.Title, P.Score
FROM dbo.Posts P
INNER JOIN dbo.Users U ON U.Id = P.OwnerUserId
WHERE U.Location = 'Columbus, OH'






# StirTrek 2017 : So What's This Yarn Thing All About?

Thank you for attending!

## Presenter:

Jeff Valore

Twitter: @CodingWithSpike

Blog: codingwithspike.com

I'm also on the Cleveland Tech Slack channel.

## Contents:

**yarn.pptx** - Powerpoint presentation used during the talk.

**speaker notes.md** - The notes I had printed and on the podeum, so that I didn't have to use "Presenter View" in Powerpoint.

**demo-directories.7z** - a 7zip archive that contains the following:

**demo-npm-repo** & **demo-yarn-repo** - a `git init --bare` local repository to commit to. Jenkins build was linked to this.

**demo-npm** & **demo-yarn** - a `git init` repository used to install packages into. Already has a `git remote origin` set to its demo-x-repo directory.
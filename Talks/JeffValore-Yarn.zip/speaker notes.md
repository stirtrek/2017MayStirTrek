# Intro

* who am i?
* contributor - 1 PR
* why pay any attention to Yarn? shinny new toy.
* tldr version; use yarn until it doesn't work

# What is Yarn?

* drop in replacement for npm CLIENT
* collaboration between devs at 4 companies
* Tilde = Yehuda Katz, who also worked on Ruby Bundler
* but now open source

# It's the Same

* you can use both in the same repo

### (next slide)

* pessimistic reaction
* understand the problem space
	* npm is non deterministic
	* at Facebook, CI servers are cut off from public internet

# Install (no slide)

* Windows
	* msi
	* chocolatey
* Mac
	* Homebrew (possible nvm compat issue?)
	* MacPorts
* Linux
	* apt-get but have to add a package source
* Any
	* curl installer
	* npm install -g yarn (not recommended but probably fine)

-----

# Demo

Going to demonstrate NPM non-deterministic breaking CI

* quick tour (cmd, atom, fiddler, jenkins, dir structure, git)
* init (and setup test script)
* install jest
* install moment@2.10.5
* check fiddler
* show test
* npm test (pass)
* git add / commit
* -- *pretend time passes and moment releases new version*
* jenkins (npm fail, yarn pass)

* -- (next slide) **deterministic**
* inspect package.json and yarn.lock

* rm -rf node_modules
* npm install / yarn install
* test (npm fail, yarn pass)

### Could solve with Shrinkwrap or committing node_modules (no slide)
* npm shrinkwrap
	* manual process to update
	* people forget to re-run and commit change
	* shrinkwrap file is nondeterministic and sometimes bigger diff than desired
* commit node_modules
	* way too many files, usually more than your actual project
	* can result is massive diffs of 3rd party code


### (next slide)

* committing node_modules
* quote from facebook

* -- (next slide) **speed**
* rm -rf node_modules
* Measure-Command { npm install }
* check fiddler (yarn makes no requests 2nd time)
* on real internet, jest & moment, 50s vs 30s
* npm makes http requests even though cached; checking for new versions

* -- (next slide) **network retries**
* thanks to garbage wifi for making this happen
* but no network use if packages downloaded already anyway; more reliable

* -- (next slide) **offline**
* turn off network
* rm -rf node_modules
* install (npm fails, yarn works)

* -- (next slide) **deployable cache**
* remember, CI servers not on internet; can't d/l packages 1st time
* cache dir, cache ls, cache clean
* don't commit node_modules

    yarn-offline-mirror "./npm-packages-offline-cache"
    yarn-offline-mirror-pruning true
    
* yarn install
* ls npm-packages-offline-cache
* -- empty?!
* have to rm -rf node_modules first
* compare file size to node_modules (cache is 10% the size)
* git add & commit npm-packages-offline-cache
* jenkins yarn

-----

# Bonus features

* yarn licenses ls (requires network to d/l license text)
* yarn why <pkg>
* convert a project by just running yarn install
* npm commands will still work in a yarn project

# (next slide - very nice!)

# (next slide - github metrics)

* npm since 2009
	* mature
	* lots of features
	* lots of resolved bugs
	* many listed github issues are that packages didn't install
* yarn since 2016
	* catching up
	* great ideas / improvements
	* many listed github issues are legitimate

# What's not the same? Known issues

* bin symlinks
* confusion: upgrade command with and without package name
* npm install -g . (not supported yet)
* npm link / yarn link (buggy?)

# Closing

* use yarn until it doesn't work, then use npm
* slides available somewhere